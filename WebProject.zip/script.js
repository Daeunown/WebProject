var main_buttoncolor;

function init(){
  main_buttonnight=document.getElementById("first-mainbutton");
  main_buttonday=document.getElementById("second-mainbutton");
  main_color=document.getElementById("submain");
  var current=new Date();
  

    main_buttonnight.onmouseover=function(){
      this.style.backgroundColor="#0e164e";
      this.style.color="white";
    }
    main_buttonnight.onmouseout=function(){
      this.style.backgroundColor="white";
      this.style.color="black";
    }

    main_buttonday.onmouseover=function(){
      this.style.backgroundColor="#d7681d";
      this.style.color="white";
    }
    main_buttonday.onmouseout=function(){
      this.style.backgroundColor="white";
      this.style.color="black";
    }

  if(current.getHours()<=12){
    main_color.style.backgroundColor="rgb(20, 146, 255)";
  }
  else{
    main_color.style.backgroundColor="black";
  }

}

var check=0;
function findChecked(e){
  if(e.checked){
    return check++;
  }
}
function alertChecked(){
  if(check==4){
    alert("정답! 모두 빅데이터가 활용되는 분야입니다^^")
  }
  else{
  alert("틀렸습니다! 정답은 모두입니다^^")  
  }
}

function canvasDraw() 
      {
            var canvas = document.getElementById("myCanvas");
            var context = canvas.getContext("2d");
            var startX, startY, endX, endY, dragging;

            canvas.addEventListener("mousedown", function (e) { down(e) });
            canvas.addEventListener("mouseup", function (e) { up(e) });
            canvas.addEventListener("mousemove", function(e) { move(e) });
            canvas.addEventListener("mouseout", function (e) { out(e) });

            function down(e)
            {
              dragging = true;
               startX = e.offsetX;
               startY = e.offsetY;
               context.strokeStyle = document.getElementById("color").value;
               context.lineWidth = document.getElementById("lineWidth").value;
            }

            function up(e)
            {
               dragging = false;
            }

            function out(e)
            {
               dragging = false;
            }

            function move(e)
            {
               if(dragging)
               {
                  endX = e.offsetX;
                  endY = e.offsetY;

                  context.beginPath();
                  context.moveTo(startX, startY);
                  context.lineTo(endX, endY);
                  context.stroke();

                  startX = e.offsetX;
                  startY = e.offsetY;
               }
            }
         }